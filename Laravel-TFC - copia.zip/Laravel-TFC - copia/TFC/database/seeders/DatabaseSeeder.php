<?php

namespace Database\Seeders;

use App\Models\Game;
use App\Models\GameSession;
use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
         User::factory(10)->create();
         Game::factory()->create([
             'name' => 'Penalty Shoot-out',
             'descripcion' => 'Penalty Shoot-out es un juego de casino basado en la emoción de los tiros penales. Apuesta, elige tu tiro y desafía al portero para ganar grandes premios. ¡Pon a prueba tu suerte y precisión!',
         ]);
        Game::factory()->create([
            'name' => 'Plinko',
            'descripcion' => 'Plinko es un emocionante juego de casino donde dejas caer una ficha desde la parte superior de un tablero y observas cómo rebota entre clavijas hasta aterrizar en un premio. ¡Apuesta, juega y gana al azar',
        ]);


         GameSession::factory(10)->create();

        $this->call(RolesAndPermissionsSeeder::class);
    }
}
