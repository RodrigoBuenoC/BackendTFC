<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Usuario\Desktop\Laravel-TFC\TFC\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>