<?php echo e($slot); ?>

<?php /**PATH C:\Users\Usuario\Desktop\Laravel-TFC\TFC\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>